"use strict";

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

ecodeSDK.overwriteClassFnQueueMapSet('WeaBrowser', {
  fn: function fn(Com, newProps) {
    //进行位置判断
    if (!ecodeSDK.checkLPath('/spa/workflow/static4form/index.html#/main/workflow/req')) return;
    var _ecCom = ecCom,
        WeaTools = _ecCom.WeaTools;
    var callApi = WeaTools.callApi;
    var baseInfo = WfForm.getBaseInfo();
    if (newProps.type != 9) return;
    if (baseInfo.workflowid != 2) return;
    if (newProps._noOverWrite) return;
    if (window.console) console.log("hs:907====newProps11", newProps); //2020/5/30 下午1:55 hs    end   

    var _ecCom2 = ecCom,
        WeaBrowser = _ecCom2.WeaBrowser;
    newProps.Com = Com;

    if (newProps.replaceDatas && newProps.replaceDatas[0] && newProps.replaceDatas[0].id && newProps.replaceDatas[0].id != '') {
      if (window.console) console.log("hs:907====newProps", newProps); //2020/5/30 下午1:55 hs    end   

      var docid = newProps.replaceDatas[0].id;
      return {
        com: function com() {
          return React.createElement("div", {
            className: "ecode-znsbbtn"
          }, React.createElement(WeaBrowser, _extends({}, newProps, {
            _noOverWrite: true
          })), " ", React.createElement("div", {
            className: "wea-upload-morebutton",
            onClick: function onClick(v) {
              // if(window.console) console.log("hs:907====docid",docid); //2020/5/30 下午1:55 hs    end   
              callApi('/api/custom/pdf2word/collect', 'get', {
                wfid: baseInfo.workflowid,
                docid: docid
              }).then(function (data) {
                //if(window.console) console.log("hs:551====docdata",data); //2020/5/30 下午1:56 hs    end 
                if (data.status != 0) return;
                var docdata = data.apidata.data;
                var docfieldid0 = WfForm.convertFieldNameToId('' + docdata[0].fieldname);
                var docvalue = WfForm.getFieldValue(docfieldid0);

                if (docvalue != "") {
                  WfForm.showConfirm("是否覆盖已有数据？", function () {
                    for (index in docdata) {
                      var docfieldid = WfForm.convertFieldNameToId('' + docdata[index].fieldname);
                      WfForm.changeFieldValue(docfieldid, {
                        value: docdata[index].value
                      });
                    }
                  });
                } else {
                  for (index in docdata) {
                    var docfieldid = WfForm.convertFieldNameToId('' + docdata[index].fieldname);
                    WfForm.changeFieldValue(docfieldid, {
                      value: docdata[index].value
                    });
                  }
                }
              });
            }
          }, "\u667A\u80FD\u8BC6\u522B"));
        },
        props: newProps
      };
    }
  },
  order: 1,
  //排序字段，如果存在同一个页面复写了同一个组件，控制顺序时使用
  desc: '正文浏览按钮智能识别'
});
