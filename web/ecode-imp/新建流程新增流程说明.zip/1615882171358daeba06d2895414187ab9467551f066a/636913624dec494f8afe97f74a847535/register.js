let enable = true;
// let bak ="";
 //let id="";



let idArr = [];

const asyncFn = ()=>{
  setTimeout(()=>{
    idArr = ['9']; //异步赋值，这里不能用组件库的WeaTools，因为执行时间比较早
  },1000);
}

asyncFn();

ecodeSDK.overwritePropsFnQueueMapSet('Card',{
  fn:(newProps,name) => {
    if(!enable) return ;
    const {hash} = window.location;
    if(!hash.startsWith('#/main/workflow/add')) return ;
    const ch = newProps.children;
    
    if(ch&&ch[1]&&ch[1].length>0) {
      let arr = ch[1];
      
      for(let i=0;i<arr.length;i++) {
        const obj = arr[i]||{};
        const wfbean = (obj.props?obj.props.wfbean:{})||{};
        // if(window.console) console.log("lth:513====",wfbean); //2020/8/26, 11:14 AM lth    end   
       let id = wfbean.id;
      let wfdesc=wfbean.wfdesc;
       // if(idArr.indexOf(wfbean.id)>=0) { //找到组件
          // if(window.console) console.log("hs:265====", newProps.children[1][i]); //2020/8/26 上午9:26 hs    end 
          let bak = newProps.children[1][i];  
           const { Tooltip} = antd;
           const {  WeaHelpfulTip}=ecCom;
           const text = <pre>{wfdesc}</pre> ;
           if(wfdesc == ""){
             // if(window.console) console.log("hs:589====",); //2020/8/26 上午11:38 hs    end   
              newProps.children[1][i] = (<div>{bak}</div>);
           }else{
              //if(window.console) console.log("hs:438====wfdesc",text); //2020/8/26 上午11:50 hs    end   
              newProps.children[1][i] = (
            <div className="addicon" title="" >
                  {bak}
              <div className="iconhide">
                <Tooltip placement="top" title={text}>
                  <i className="icon-coms-help" />
                </Tooltip>
              </div>
            </div>
        );
           }
         
        //}
      }
    }
  }
});

const LinkItem = (props)=>{
  
    return (
      
        <div className="addicon" title="1212" >
           {bak}
           <div className="iconhide">
           <i className="icon-coms-Message-center" title={id} />
          </div>
        </div>
    )
}
