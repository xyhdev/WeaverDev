"use strict";

var enable = true; // let bak ="";
//let id="";

var idArr = [];

var asyncFn = function asyncFn() {
  setTimeout(function () {
    idArr = ['9']; //异步赋值，这里不能用组件库的WeaTools，因为执行时间比较早
  }, 1000);
};

asyncFn();
ecodeSDK.overwritePropsFnQueueMapSet('Card', {
  fn: function fn(newProps, name) {
    if (!enable) return;
    var hash = window.location.hash;
    if (!hash.startsWith('#/main/workflow/add')) return;
    var ch = newProps.children;

    if (ch && ch[1] && ch[1].length > 0) {
      var arr = ch[1];

      for (var i = 0; i < arr.length; i++) {
        var obj = arr[i] || {};
        var wfbean = (obj.props ? obj.props.wfbean : {}) || {}; // if(window.console) console.log("lth:513====",wfbean); //2020/8/26, 11:14 AM lth    end   

        var _id = wfbean.id;
        var wfdesc = wfbean.wfdesc; // if(idArr.indexOf(wfbean.id)>=0) { //找到组件
        // if(window.console) console.log("hs:265====", newProps.children[1][i]); //2020/8/26 上午9:26 hs    end 

        var _bak = newProps.children[1][i];
        var _antd = antd,
            Tooltip = _antd.Tooltip;
        var _ecCom = ecCom,
            WeaHelpfulTip = _ecCom.WeaHelpfulTip;
        var text = React.createElement("pre", null, wfdesc);

        if (wfdesc == "") {
          // if(window.console) console.log("hs:589====",); //2020/8/26 上午11:38 hs    end   
          newProps.children[1][i] = React.createElement("div", null, _bak);
        } else {
          //if(window.console) console.log("hs:438====wfdesc",text); //2020/8/26 上午11:50 hs    end   
          newProps.children[1][i] = React.createElement("div", {
            className: "addicon",
            title: ""
          }, _bak, React.createElement("div", {
            className: "iconhide"
          }, React.createElement(Tooltip, {
            placement: "top",
            title: text
          }, React.createElement("i", {
            className: "icon-coms-help"
          }))));
        } //}

      }
    }
  }
});

var LinkItem = function LinkItem(props) {
  return React.createElement("div", {
    className: "addicon",
    title: "1212"
  }, bak, React.createElement("div", {
    className: "iconhide"
  }, React.createElement("i", {
    className: "icon-coms-Message-center",
    title: id
  })));
};